setInterval(() => {
    console.log('hello from service worker')
}, 1000);